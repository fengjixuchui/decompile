package buwai.android.shell.base;

/**
 * Created by buwai on 2015/4/1.
 */
public class Common {

    public static final int API = 14;

    public static final String SO_NAME = "advmp";

}

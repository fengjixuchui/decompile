#include "Globals.h"

ADVMPGlobals gAdvmp;

const char* gYcFileName = "classes.yc";

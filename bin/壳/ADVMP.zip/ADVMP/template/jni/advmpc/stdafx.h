#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <jni.h>
#include <string.h>
#include <stddef.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>

#include "Common.h"

#include "Object.h"
#include "Exception.h"

#include "log.h"

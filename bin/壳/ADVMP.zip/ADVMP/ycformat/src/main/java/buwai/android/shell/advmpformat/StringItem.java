package buwai.android.shell.advmpformat;

/**
 * Created by buwai on 2015/4/3.
 */
public class StringItem {

    /**
     * 字符串中字符个数。
     */
    public int size;

    /**
     * 字符数组。
     */
    public byte[] str;

}

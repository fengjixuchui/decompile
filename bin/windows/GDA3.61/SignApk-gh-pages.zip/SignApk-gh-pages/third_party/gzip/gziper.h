
#ifndef INCLUDE_GZIPER_H
#define INCLUDE_GZIPER_H

#include <string>

std::string decompress( void *compr, unsigned long len );
std::string decompress2( void *compr, unsigned long len );

#endif // INCLUDE_GZIPER_H
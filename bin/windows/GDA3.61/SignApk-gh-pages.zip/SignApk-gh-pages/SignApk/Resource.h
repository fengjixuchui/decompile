//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CMReadUpack.rc
//
#define IDR_SKINXML                     101
#define IDR_PNG_MINIMIZE                103
#define IDR_PNG_MINIMIZE_H              104
#define IDR_PNG_MINIMIZE_P              105
#define IDR_PNG_MAXIMIZE                106
#define IDR_PNG_MAXIMIZE_H              107
#define IDR_PNG_MAXIMIZE_P              108
#define IDR_PNG_RESTORE                 109
#define IDR_PNG_RESTORE_H               110
#define IDR_PNG_RESTORE_P               111
#define IDR_PNG_CLOSE                   112
#define IDR_PNG_CLOSE_H                 113
#define IDR_PNG_CLOSE_P                 114
#define IDR_PNG_BUTTON                  115
#define IDR_PNG_BUTTON_H                116
#define IDR_PNG_BUTTON_P                117
#define IDR_PNG_COMBOX                  118
#define IDR_PNG_SCROLLBAR_V             119
#define IDR_PNG_SCROLLBAR_H             120
#define IDR_PNG_MENU_BK                 121
#define IDR_PNG_MENU_EXPAND             122
#define IDR_XML_MENU                    123
#define IDR_PNG_CHECKBOX                124
#define IDR_PNG_CHECKBOX_H              125
#define IDR_PNG_CHECKBOX_P              126
#define IDR_PNG_RADIO                   127
#define IDR_PNG_RADIO_H                 128
#define IDR_PNG_RADIO_P                 129
#define IDR_PNG_SLIDER_BG               130
#define IDR_PNG_SLIDER_FG               131
#define IDR_PNG_SLIDER_THUMB            132
#define IDR_PNG_RATING                  133
#define IDR_PNG_RATING_D                134
#define IDR_PNG_BG                      135
#define IDR_BMP_BG                      136
#define IDR_XML_MSGBOX                  137
#define IDI_ICON1                       138
#define IDR_PNG_UNPACK					139
#define IDR_PNG_LIST_HEADER				140
#define IDR_PNG_LIST_SELECT				141
#define IDR_PNG_LIST_HEADER_SEP			142
#define IDR_XML_LIST_ITEM				143

#define IDR_PNG_SEPERATOR				144

#define IDR_PNG_PROGRESS_BG				145
#define IDR_PNG_PROGRESS_FG				146

#define IDR_PNG_PACK					301
#define IDR_PNG_SETTING					302
#define IDR_PNG_LOGO					303
#define IDR_PNG_TAB_V					304
#define IDR_PNG_TAB_V_P					305
#define IDR_PNG_CLEAR					306
#define IDR_PNG_ADD						307
#define IDR_PNG_EDIT					308
#define IDR_PNG_DELETE					309

#define IDR_PNG_LOG2					310

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

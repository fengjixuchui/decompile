package com.pnfsoftware;

import jeb.api.IScript;
import jeb.api.JebInstance;

public class JebPlugin implements IScript {

    @Override
    public void run(JebInstance jeb) {
        jeb.print("Hello, JEB");
    }
}
